package com.dnp.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    private String TAG  =  MainActivity.class.getSimpleName();
    private ProgressDialog pDialog;
    private ListView lv;

    //URL JSON

    private static String url="https://api.androidhive.info/contacts/";

    ArrayList<HashMap<String, String>> contactlist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        contactlist = new ArrayList<>();

        lv = (ListView) findViewById(R.id.listView);

        new GetContacts().execute();

    }

    private class GetContacts extends AsyncTask<Void,Void,Void>{
        @Override
        protected void onPreExecute(){
            super.onPreExecute();
            pDialog = new ProgressDialog(MainActivity.this);
            pDialog.setMessage("Tunggu...");
            pDialog.setCancelable(false);
            pDialog.show();
        }
        @Override
        protected Void doInBackground(Void... voids) {
            HttpHandler sh = new HttpHandler();
            String jsonStr = sh.makeServiceCall(url);

            Log.e(TAG,"Response from url" + jsonStr);
            if (jsonStr !=null){
                try {

                    JSONObject jsonObject = new JSONObject(jsonStr);

                    //json array node
                    JSONArray contacts = jsonObject.getJSONArray("contacts");

                    //looping
                    for (int i = 0; i < contacts.length();i++){
                        JSONObject c = contacts.getJSONObject(i);

                        String id = c.getString("id");
                        String name = c.getString("name");
                        String email = c.getString("email");
                        String address = c.getString("address");
                        String gender = c.getString("gender");

                        //phone node json
                        JSONObject phone = c.getJSONObject("phone");
                        String mobile = phone.getString("mobile");
                        String home = phone.getString("home");
                        String office = phone.getString("office");

                        HashMap<String,String> contact = new HashMap<>();
                        //add child hashmap
                        contact.put("id",id);
                        contact.put("name",name);
                        contact.put("email",email);
                        contact.put("home",home);
                        contact.put("office",office);
                        contact.put("address",address);
                        contact.put("mobile",mobile);
                        contact.put("gender",gender);

                        //add contact
                        contactlist.add(contact);


                    }
                }catch (final JSONException e){
                    Log.e(TAG,"JOSN parsing error" + e.getMessage());
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(MainActivity.this,
                                    "Json parsing error: " + e.getMessage(),
                                    Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            } else {
                Log.e(TAG,"Couldn't get json from server.");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivity.this,
                                "Couldn't get json from server.",
                                Toast.LENGTH_SHORT).show();
                    }
                });            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            //dismiss dialog
            if(pDialog.isShowing()){
                pDialog.dismiss();
            }
            //updatejson to listview
            ListAdapter adapter= new SimpleAdapter(
                    MainActivity.this, contactlist,
                    R.layout.list_item, new String[]{"id","name","email","address","gender","mobile","home","office"},
                    new int[]{R.id.id,R.id.name,R.id.email,R.id.address,R.id.gender,R.id.mobile,R.id.home,R.id.office});
            lv.setAdapter(adapter);
        }
    }

}